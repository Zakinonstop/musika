<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="text-center mt-5">
        <h2>CodeIgniter 4 Coba</h2>
    </div>
</div>
<?= $this->endSection(); ?>